// Fonction serverless Vercel — stocke/lit les données de JARVIS dans Postgres (Neon).
// Déclenchée sur GET /api/state (lecture) et PUT /api/state (écriture).

const { neon } = require('@neondatabase/serverless');

function checkAuth(req) {
  const password = process.env.JARVIS_PASSWORD;
  if (!password) return true; // aucune protection configurée
  return req.headers['x-jarvis-key'] === password;
}

module.exports = async function handler(req, res) {
  if (!checkAuth(req)) {
    res.status(401).json({ error: 'unauthorized' });
    return;
  }

  const connectionString =
    process.env.DATABASE_URL ||
    process.env.POSTGRES_URL ||
    process.env.DATABASE_URL_UNPOOLED;

  if (!connectionString) {
    res.status(500).json({
      error: 'Aucune variable de connexion à la base de données trouvée (DATABASE_URL).',
    });
    return;
  }

  const sql = neon(connectionString);

  try {
    // Crée la table au premier appel si elle n'existe pas encore.
    await sql`
      CREATE TABLE IF NOT EXISTS jarvis_state (
        id INT PRIMARY KEY DEFAULT 1,
        data JSONB NOT NULL DEFAULT '{}'::jsonb,
        updated_at TIMESTAMPTZ DEFAULT now()
      )
    `;

    if (req.method === 'GET') {
      const rows = await sql`SELECT data FROM jarvis_state WHERE id = 1`;
      if (rows.length === 0) {
        await sql`INSERT INTO jarvis_state (id, data) VALUES (1, '{}'::jsonb)`;
        res.status(200).json({});
        return;
      }
      res.status(200).json(rows[0].data);
      return;
    }

    if (req.method === 'PUT') {
      const body = req.body || {};
      const json = JSON.stringify(body);
      await sql`
        INSERT INTO jarvis_state (id, data, updated_at)
        VALUES (1, ${json}::jsonb, now())
        ON CONFLICT (id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()
      `;
      res.status(200).json({ ok: true });
      return;
    }

    res.status(405).json({ error: 'method not allowed' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'database error', detail: String(err.message || err) });
  }
};
