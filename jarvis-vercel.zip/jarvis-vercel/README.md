# JARVIS — version en ligne (Vercel + base de données Postgres)

Ce dossier contient une version de JARVIS qui stocke ses données dans une
vraie base de données Postgres (via Neon), hébergée sur Vercel, au lieu du
stockage local propre à l'artefact Claude. Résultat : vous pouvez y accéder
depuis n'importe quel appareil, à une adresse fixe (ex.
`https://jarvis-alex.vercel.app`), et les données survivent indéfiniment.

Aucune ligne de commande n'est nécessaire — tout se fait depuis les sites
web de GitHub et Vercel.

## Ce dont vous avez besoin

- Un compte GitHub (gratuit) — https://github.com/signup
- Un compte Vercel (gratuit) — https://vercel.com/signup (vous pouvez vous
  inscrire directement avec votre compte GitHub, c'est plus rapide)

## Étape 1 — Mettre le code sur GitHub

1. Allez sur https://github.com/new
2. Nom du dépôt : `jarvis` (ou ce que vous voulez), laissez-le en **Private**
   si vous préférez, puis cliquez **Create repository**.
3. Sur la page du nouveau dépôt vide, cliquez **uploading an existing file**.
4. Glissez-déposez les 3 éléments de ce dossier :
   - `index.html`
   - `package.json`
   - le dossier `api` (avec `state.js` dedans)
5. Cliquez **Commit changes**.

## Étape 2 — Déployer sur Vercel

1. Allez sur https://vercel.com/new
2. Choisissez **Import** sur le dépôt `jarvis` que vous venez de créer.
3. Laissez les réglages par défaut (Framework Preset : *Other*) et cliquez
   **Deploy**. Le premier déploiement fonctionnera, mais l'application
   affichera une erreur tant que la base de données n'est pas branchée
   (étape suivante) — c'est normal.

## Étape 3 — Ajouter la base de données (Neon, gratuite)

1. Dans votre projet Vercel, ouvrez l'onglet **Storage**.
2. Cliquez **Create Database** (ou **Connect Database** selon l'interface),
   choisissez **Neon** (Postgres serverless) dans le Marketplace, puis
   suivez l'assistant (nom, région la plus proche — Europe/Paris ou Frankfurt).
3. Une fois créée, Vercel connecte automatiquement la base à votre projet et
   ajoute une variable d'environnement (généralement `DATABASE_URL`).
4. Allez dans **Settings → Environment Variables** de votre projet et
   vérifiez qu'une variable contenant l'URL de connexion existe. Si elle ne
   s'appelle pas `DATABASE_URL`, notez son nom exact.

## Étape 4 — Protéger l'accès par un code

Vos données étant personnelles, ajoutez un mot de passe simple :

1. Toujours dans **Settings → Environment Variables**, ajoutez :
   - Nom : `JARVIS_PASSWORD`
   - Valeur : le code de votre choix (ex. `4Corniches19`)
2. Sauvegardez.

## Étape 5 — Redéployer

Les variables d'environnement ne s'appliquent qu'aux nouveaux déploiements :

1. Allez dans l'onglet **Deployments**.
2. Sur le déploiement le plus récent, cliquez le menu **⋯** puis
   **Redeploy**.

## Étape 6 — Utiliser JARVIS

1. Ouvrez l'URL de votre projet (visible en haut du dashboard Vercel,
   du type `https://jarvis-xxxxx.vercel.app`).
2. Entrez le code défini à l'étape 4.
3. C'est en ligne. Ajoutez-la à l'écran d'accueil de votre téléphone comme
   précédemment (bannière en haut du tableau de bord → « Comment faire »).

## Récupérer vos données actuelles

Si vous utilisiez déjà JARVIS dans Claude :

1. Dans l'ancienne version, ouvrez l'onglet **Planning** → icône ⚙ →
   section **Sauvegarde des données** → **Copier**.
2. Dans la nouvelle version en ligne, ouvrez **Planning** → ⚙ →
   **Importer** → collez → **Importer et remplacer**.

## Si quelque chose ne fonctionne pas

- **Page blanche ou erreur 500** : la variable de connexion à la base de
  données ne s'appelle probablement pas `DATABASE_URL`. Ouvrez
  `api/state.js` sur GitHub, modifiez la ligne qui lit
  `process.env.DATABASE_URL` pour utiliser le nom exact trouvé dans
  Vercel, puis re-déployez (chaque modification sur GitHub redéploie
  automatiquement).
- **Le code d'accès ne fonctionne jamais** : vérifiez que la variable
  `JARVIS_PASSWORD` a bien été ajoutée *avant* le redéploiement de
  l'étape 5.
- **Coûts** : les paliers gratuits de Vercel et Neon suffisent largement
  pour un usage personnel comme celui-ci.
